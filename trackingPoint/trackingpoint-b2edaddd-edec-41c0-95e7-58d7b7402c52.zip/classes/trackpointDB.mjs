


import { sha256,sha256_hmac,makeid } from './functions.mjs';
import {ObjectId} from 'mongodb';

var date = new Date();
var localeDate = date.toLocaleString('he-IL'); // to get the full date string
var unix = Date.now(); // to get the full date string



// export class UsersDB {
//   constructor(client) {
//     this.client = client;
//   }
    var hashCode = 'nRIi81TqUWkqf3J3GUFwAAV9j52B09J48rImqV6W2bHtcsEna0DBE5adV5MMIrRQ';
    
    
    export async function listDatabases(client){
        const databasesList = client.db().admin().listDatabases();
        console.log("Databases:");
        databasesList.databases.forEach(db => console.log(` - ${db.name}`));
    };
    export async function makeClientToken(ip,origin,pointKey,sessionKey,key) {
        var string = await ip + '-' + await origin + '-' + await pointKey + '-' + await sessionKey + '-' + await key;
        var do_hash = await sha256_hmac(string,hashCode);
        return await do_hash;

    }
     export async function eventTP(client,ip,sessionKey,pointKey,type,subtype,data,ch_platform,UserAgent,key){
            const EventColl = await client.db('trackingpoint').collection('Events');
            var do_user_hash = await sha256_hmac(key,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");

            if(type != "customer"){
                const inserArr = await [{
                    key: do_user_hash,
                    user_agent: UserAgent,
                    ch_platform: ch_platform,
                    ip: ip,
                    type: type,
                    subtype: subtype,
                    point_key: pointKey,
                    session_key: sessionKey,
                    data:data,
                    unix: unix,
                    date: localeDate
                }]
                const insertNewCustomer = await EventColl.insertMany(inserArr);
                return insertNewCustomer;
            }else{
                const CustomersColl = await client.db('trackingpoint').collection('Customers');
                const resUpdateConnections = await EventColl.updateOne(
                  { email: data.email },
                  { 
                      
                      $push: { 
                          user:do_user_hash,
                          sp: {
                              date: localeDate,
                              unixtime: unix,
                              session_key: sessionKey,
                              point_key: pointKey
                          }
                          
                           
                      }
                       
                  },{ 
                      upsert: true 
                  }
                );
                return resUpdateConnections;
            }
        }
        
        
    
    export async function login(client,username,password,ip){
        var do_pass_hash = await sha256_hmac(password,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
        const filter =  {
          email: username,
          pass_hash: do_pass_hash
        };
        const coll = await client.db('Tamar').collection('Users');
        
        const cursor = await coll.findOne(filter);
        
        // const result = await cursor.limit(1).toArray();
        
        if(cursor !== null){
            //  var session = await makeid(60);
             var token = await makeid(120);
             var do_token_hash = await sha256_hmac(token,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
             var api_key = await makeid(80)
             var key_hash = await sha256_hmac(api_key,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
        
            const resUpdateConnections = await client.db('Tamar').collection('Users').updateOne(
              { email: username },
              { 
                  
                  $push: { 
                      
                      connections: {
                          ip :ip,
                          date: date,
                          unixtime: unix,
                          token: do_token_hash
                          
                      },
                      api_keys: {
                          date: localeDate,
                          unixtime: unix,
                          key_hash: key_hash,
                          active: true
                      }
                      
                       
                  }
                   
              }
            );
             const res = await {"status": true,"msg": "User login successfuly","token": token, "api_key": api_key, "user_id": cursor._id}

            return res;
        }else{
            const res = await {"status": false, "msg": "User login error"}
            return res;
        }
        
        
    };
    export async function checkToken(client,token,ip){
        var token = await sha256_hmac(token,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
        const filter =  {
          
           connections: 
               {
                   $elemMatch:
                   {
                       ip :ip,
                       token: token
                       
                   }
               },
               active: true
        };
        const coll = await client.db('Tamar').collection('Users');
        const cursor = await coll.findOne(filter);
        if(cursor !== null){
             const result = await cursor;
            const res = await {"status": true,"id":cursor._id,"email":cursor.email,"accept_marketing":cursor.accept_marketing,"API_Planes":cursor.API_Planes,"api_tokens": cursor.api_tokens}
            return res;
        }else{
            const res = await {"status": false,"message":"User login error"}
            return res;
        }
    };
    
    
    
     export async function signup(client,username,password,accept_marketing,ip){

        //  const res = await {};
        const filter =  {
          email: username
        };
        const coll =  client.db('Tamar').collection('Users');
        
        var findEmail = await coll.findOne(filter);
        if(findEmail !== null){
            const res = await {"error": "this email alreay exist"}
            return res;
        }else{
            var do_pass_hash = await sha256_hmac(password,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
            const inserArr = await [{
                email: username,
                password: do_pass_hash,
                accept_marketing: accept_marketing,
                active: true,
                API_Planes: 4


            }]
            const insertNewUser = await coll.insertMany(inserArr);
            const res = await {"success": "New user add successfuly"}
             await login(client,username,password,ip);

            return res;
            // const result = await cursor.limit(1).toArray();
        }
    };
    export async function new_api(client,user_id){
        
        //  const res = await {};
        var api_key = await makeid(80)
        var key_hash = await sha256_hmac(api_key,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
         const resUpdateConnections = await client.db('Tamar').collection('Users').updateOne(
              { _id: new ObjectId(user_id) },
              { 
                  
                  $push: { 
                      
                      api_keys: {
                          date: localeDate,
                          unixtime: unix,
                          key_hash: key_hash,
                          active: true
                      }
                       
                  }
                   
              }
            );
            console.log(resUpdateConnections)
            return await api_key;
            
        // const coll = await client.db('Tamar').collection('Users');
        // const cursor = await coll.findOne(filter);
        // if(cursor !== null){
        //      const result = await cursor;
        //     const res = await {"status": true,"email":cursor.email,"accept_marketing":cursor.accept_marketing,"API_Planes":cursor.API_Planes,"api_tokens": cursor.api_tokens}
        //     return res;
        // }else{
        //     const res = await {"status": false,"message":"User login error"}
        //     return res;
        // }
    };
    
    export async function api_usage(client,user_id,api_key,type){
        const res = await {};
        var key_hash = await sha256_hmac(api_key,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
        const filter = await 
        {
          '_id': new ObjectId(user_id),
          active: true,
           api_keys: 
               {
                   
                   $elemMatch:
                   {
                       key_hash: key_hash,
                       active: true
                   }
               }
            
        };
        const coll = await client.db('Tamar').collection('Users');
        const cursor = await coll.findOne(filter);
        // return cursor
        
        
        if(cursor !== null){
            const currentDate = new Date();

            // Set the time to the start of the day (midnight)
           // Get the start of the day in UNIX timestamp
            const startOfDayUTC = new Date();
            startOfDayUTC.setUTCHours(0, 0, 0, 0);
            const startOfDayUnixUTC = Math.floor(startOfDayUTC.getTime()); // convert to seconds
            
            // Get the end of the day in UNIX timestamp
            const endOfDayUTC = new Date();
            endOfDayUTC.setUTCHours(23, 59, 59, 999);
            const endOfDayUnixUTC = Math.floor(endOfDayUTC.getTime()); // convert to seconds

            
            // console.log(cursor);
            //  const result = await cursor;
            // const res = await {"status": true,"email":cursor.email,"accept_marketing":cursor.accept_marketing,"API_Planes":cursor.API_Planes,"api_tokens": cursor.api_tokens}
            
            // const startOfToday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
            // const endOfToday = new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1);
            
             const filterOfAPI_UsageCursor =  {
                   user_id: user_id,
                   key_hash: key_hash,
                   
                       unixtime:{
                           $gte:startOfDayUnixUTC,
                           $lt:endOfDayUnixUTC
                           
                       }
                       
                   
            };
            console.log(startOfDayUnixUTC,endOfDayUnixUTC)
    
            const API_UsageColl = await client.db('Tamar').collection('API_Usage');
            const API_UsageCursor = await API_UsageColl.countDocuments(filterOfAPI_UsageCursor);
            console.log(API_UsageCursor);
            res.use = await API_UsageCursor;
            if(API_UsageCursor > cursor.API_Planes){
                res.status = false
                res.error = await "Sorry, You have limited of the API Requests plane per day";
                res.limit = await cursor.API_Planes;
                
            }else{
                
                const inserArr = await [{
                    user_id: user_id,
                    key_hash: key_hash,
                    date: localeDate,
                    unixtime: unix,
                    type: type
                }]
                const insertNewAPIReq = await API_UsageColl.insertMany(inserArr);
                
                res.status = true
                res.error = await 0;
                res.limit = await cursor.API_Planes;

            }
            return await res;
        }else{
            // return cursor;
            const res = await {"status": false,"message":"API error"};
            return await res;
        }
    };
    
    
     export async function customerNew(client,user_id,info){
        var customerToken = await makeid(120)
        const res = await {};
        const customerCall = await client.db('Tamar').collection('customers');
        const currentDate = new Date();
        const inserArr = await [{
            user_id: user_id,
            date: currentDate,
            info:info,
            token: customerToken
        }]
        const insertNewCustomer = await customerCall.insertMany(inserArr);
        res = await {"customerToken":customerToken,"status": true,"message":"Customer created"};
        console.log(insertNewCustomer);
            
              

            
            return await res;
        
    };
    export async function customerList(client,user_id){
        const res = await {};
        const filter =  {
          user_id: user_id
        };
        const coll = await client.db('Tamar').collection('customers');
        
        const cursor = await coll.find(filter);
        const result = await cursor.limit(250).toArray()
        console.log(result);
            
              

            
            return await res;
        
    };
     export async function CustomerById(client,user_id,customerId){
        const res = await {};
        const filter =  {
          user_id: user_id,
          customerId: customerId
        };
        const coll = await client.db('Tamar').collection('customers');
        
        const cursor = await coll.find(filter);
        const result = await cursor.limit(250).toArray()
        console.log(result);
        return await res;
    };
    export async function customerFilter(client,user_id,info){
        const res = await {};
        const filter =  {
          user_id: user_id,
          info: info
        };
        const coll = await client.db('Tamar').collection('customers');
        
        const cursor = await coll.find(filter);
        const result = await cursor.limit(250).toArray()
        console.log(result);
        return await res;
        
    };
    
    // async function main(){
     export async function updateSuccessLogin(client,username,ip){
    
       // const coll =  client.db('Tamar').collection('Users').updateOne({ 'email': email},[{ $set: {temp_code: makeid(6),} } ,{multi: true }]);
         // Update And Push
         var str = makeid(20);
         const resUpdateConnections = await client.db('Tamar').collection('Users').updateOne(
              { email: username },
              { 
                  $push: { 
                      temp_code: str,
                      connections: {
                          ip :ip,
                          date: date,
                          unixtime: unix

                      }
                       
                  }
                   
              }
            );
        // const result = await cursor.limit(1).toArray();
        
    };
    export async function dialogueNew(client,user_id,customerId,messages,messagesInfo){
        var dialogueToken = await makeid(30) + '' + await sha256_hmac(customerId,"Mas4543d");
        //var dialogueToken_hash = await sha256_hmac(dialogueToken,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
        const res = await {};
        const dialogueCall = await client.db('Tamar').collection('dialogue');
        const currentDate = new Date();
        const inserArr = await [{
            user_id: user_id,
            customerId: customerId,
            date: currentDate,
            messages: messages,
            messagesInfo: messagesInfo,
            token:  dialogueToken
        }];
        const insertDialogue = await dialogueCall.insertMany(inserArr);
        console.log(insertDialogue);
        
        
        const resUpdate = await client.db('Tamar').collection('customers').updateOne(
              { _id: new ObjectId(customerId) },
              { 
                  
                  $push: { 
                      
                      rate: {
                         messagesInfo : messagesInfo,
                         date: currentDate

                      }
                       
                  }
                   
              }
            );
            console.log(resUpdate)
        res.dialogueToken = dialogueToken
        res.status = true
        res.message = "Dialogue created";
        res.message_grade = messages
        res.message_grade_info = messagesInfo
        

            
            return await res;
        
    };
     export async function dialogueByToken(client,token){
        const res = await {};
        const filter =  {
          token: token
        };
        const coll = await client.db('Tamar').collection('dialogue');
        
        const cursor = await coll.find(filter);
        const result = await cursor.next()
        console.log(result);
        return await result;
    };
    export async function dialogueByCustomerId(client,user_id,customerId){
        const res = await {};
        const filter =  {
          user_id: user_id,
          customerId: customerId
        };
        const coll = await client.db('Tamar').collection('dialogue');
        
        const cursor = await coll.find(filter);
        const result = await cursor.limit(250).toArray()
        console.log(result);
        return await res;
    };
    export async function dialogueByUserId(client,user_id){
        const res = await {};
        const filter =  {
          user_id: user_id
        };
        
        const coll = await client.db('Tamar').collection('dialogue');
        
        const cursor = await coll.find(filter);
        const result = await cursor.limit(250).toArray()
        console.log(result);
        return await res;
    };
//   }
    // export async function new_customer(userId,name,email){
    
    //   // const coll =  client.db('Tamar').collection('Users').updateOne({ 'email': email},[{ $set: {temp_code: makeid(6),} } ,{multi: true }]);
    //      // Update And Push
    //      var str = makeid(20);
    //      const coll =  client.db('Tamar').collection('UsersCustomers');
    //          const inserArr = await [{
    //             email: username,
    //             password: do_pass_hash,
    //             accept_marketing: accept_marketing,
    //             active: true
    //         }]
    //         const insertNewUser = await coll.insertMany(inserArr);
    //         const res = await {"success": "New user add successfuly"}
            
    //     // const result = await cursor.limit(1).toArray();
        
    // };

