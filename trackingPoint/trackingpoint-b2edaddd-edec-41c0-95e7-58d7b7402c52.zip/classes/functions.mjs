// newFile.mjs
// export function sayHello(name) {
//   console.log(`Hello, ${name}!`);
// }

// export class Person {
//   constructor(name) {
//     this.name = name;
//   }

//   greet() {
//     console.log(`Greetings, ${this.name}!`);
//   }
// }
import crypto from 'crypto';

export function sha256(data) {
    return crypto.createHash("sha256").update(data, "binary").digest("base64");
}
export async function sha256_hmac(str,secert) {
    return crypto.createHmac('sha256', secert).update(str.toString()).digest("hex");
}
export async function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}
    

// export async function sha256(data) {
//     return crypto.createHash("sha256").update(data, "binary").digest("base64");
// }
// export async function sha256_hmac(str,secert) {
//     return crypto.createHmac('sha256', secert).update(str.toString()).digest("hex");
// }

// export async function listDatabases(client){
//     const databasesList = await client.db().admin().listDatabases();
//     console.log("Databases:");
//     databasesList.databases.forEach(db => console.log(` - ${db.name}`));
// };
// export async function makeid(length) {
//     let result = '';
//     const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
//     const charactersLength = characters.length;
//     let counter = 0;
//     while (counter < length) {
//       result += characters.charAt(Math.floor(Math.random() * charactersLength));
//       counter += 1;
//     }
//     return result;
// }
// export async function login(client,username,password){
//     var do_pass_hash = await sha256_hmac(password,"MasterKeyd3d2ec859eqXlNjKpKv1c35191dc068845b4bf0e485eqXlNjKpKv16a31390e7d264c52d208b53a837ac9");
//     const filter = await {
//       email: username,
//       pass_hash: do_pass_hash
//     };
//     const coll = await client.db('Tamar').collection('Users');
    
//     const cursor = await coll.findOne(filter);
    
//     // const result = await cursor.limit(1).toArray();
    
//     return await cursor;
// };
// // async function main(){
// export async function update(client,where,to){

//     const coll = await client.db('Tamar').collection('Users').updateOne({ 'email': 'neryaelul@gmail.com'},[{ $set: {temp_code: 3434} } ,{multi: true }]);
    
//     // const result = await cursor.limit(1).toArray();
    
//     return await coll;
// };
