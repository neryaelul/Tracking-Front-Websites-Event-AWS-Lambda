

import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";

import { sha256,sha256_hmac,makeid } from './functions.mjs';

var date = new Date();
var localeDate = date.toLocaleString('he-IL'); // to get the full date string
var unix = Date.now(); // to get the full date string

export class Tamar {
    constructor(req) {
        this.req = req;
    }

    calculate() {
        
        // const res = await fetch('http://3.250.75.174:8000/calculate', {
        //   method: "post",
        //   headers: {
        //     'Accept': 'application/json',
        //     'Content-Type': 'application/json'
        //   },
        
        //   //make sure to serialize your JSON body
        //   body: JSON.stringify({
        //     sentence: 'שירות כושל',
        //   })
        // });
        // const res_data = {"res": "err"};
        
        // if (res.ok) {
        //   const data = await res.json();
        //   console.log(data);
        //   const response = {
        //       statusCode: 200,
        //       body: JSON.stringify(data),
        //   };
        //   return await response;
        // }
        
        // return `Hello, ${this.req}!`;
    }
}