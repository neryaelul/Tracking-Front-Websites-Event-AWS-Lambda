import { S3Client, ListBucketsCommand } from "@aws-sdk/client-s3";

import {MongoClient} from 'mongodb';
import {ObjectId} from 'mongodb';
//import { ObjectId } from "bson";



import { eventTP,makeClientToken } from './classes/trackpointDB.mjs';

var date = new Date();
var localeDate = date.toLocaleString('he-IL'); // to get the full date string
var unix = Date.now(); // to get the full date string
var limit_error = "Err API Limit";
// moment(date.getTime()).tz("America/Los_Angeles").format("DD-MM-YYYY");


export const handler = async(event) => {
     
        
       
        const path = event.path;
        console.log(path);
        var parms = event.queryStringParameters;
        const body = event.body;
        var ip = event['requestContext']['identity']['sourceIp'];
        const headers = event['headers'];
        const ch_platform = event['headers']['sec-ch-ua-platform'];
        const UserAgent = event['headers']['User-Agent'];
        

        var origin = headers.origin
        // var method = event['requestContext']['httpMethod'];
        //  console.log(method)
         
        // var body_parse = body; // sandbox
        if(path.includes('sandbox')){
            var body_parse = body; //prod
        }else{
            var body_parse = await JSON.parse(body); //prod
        }
        if(path.includes("/testE")){
            console.log(event);
           const response = await {
                  statusCode: 200,
                  headers: {
                      'Content-Type': 'application/json',
                      'Access-Control-Allow-Origin': '*', // Replace with your frontend application's origin
                      'Access-Control-Allow-Headers': 'Content-Type',
                      'Access-Control-Allow-Credentials': true, // Required for cookies, authorization headers with HTTPS
                      'Access-Control-Allow-Methods': '*' // Add the HTTP methods your application requires
                  },
                  body:JSON.stringify(event)
              };
              return await response;
       }
        if(path.includes("/client")){
            
            var org_key = await body_parse.org_key;
            var sessionKey = await body_parse.sessionKey;
            var pointKey = await body_parse.pointKey;

            var clientTokenMaker = await makeClientToken(ip,origin,pointKey,sessionKey,org_key);
            console.log('1+++++' + clientTokenMaker + "-------------------------------------------" + clientTokenReq + "-" + ip + "-" + origin + "-" + pointKey + "|" + sessionKey + "|" +org_key);

           const response = await {
                  statusCode: 200,
                  headers: {
                      'Content-Type': 'application/json',
                      'Access-Control-Allow-Origin': '*', // Replace with your frontend application's origin
                      'Access-Control-Allow-Headers': 'Content-Type',
                      'Access-Control-Allow-Credentials': true, // Required for cookies, authorization headers with HTTPS
                      'Access-Control-Allow-Methods': '*' // Add the HTTP methods your application requires
                  },
                    body:JSON.stringify({"token":clientTokenMaker})              
               
           };
              return await response;
       }
   
         if(path.includes("/test_one")){
                        const response = await {
                        
                          statusCode: 200,
                           headers: {
                                  'Content-Type': 'application/json',
                                  'Access-Control-Allow-Origin': '*', // Replace with your frontend application's origin
                                  'Access-Control-Allow-Headers': 'Content-Type',
                                  'Access-Control-Allow-Credentials': true, // Required for cookies, authorization headers with HTTPS
                                  'Access-Control-Allow-Methods': '*' // Add the HTTP methods your application requires
                              },
                          body:JSON.stringify({"dd":body_parse.username})
                      };
                      return await response;
                    }
        const uri = "mongodb://AdminCherry:TrCLc95Ns7GdEKV4ARMa@63.32.92.103:27017";

        const client = await new MongoClient(uri);
        await client.connect();
        try {       
                  
                    if(path.includes("/event")){

                        // await client.db("trackingpoint").collection('Events').deleteMany({});
                        const headersRes = await {
                              'Content-Type': 'application/json',
                              'Access-Control-Allow-Origin': '*', // Replace with your frontend application's origin
                              'Access-Control-Allow-Headers': 'Content-Type',
                              'Access-Control-Allow-Credentials': true, // Required for cookies, authorization headers with HTTPS
                              'Access-Control-Allow-Methods': '*' // Add the HTTP methods your application requires
                          }
                        var org_key = await body_parse.org_key;
                        var sessionKey = await body_parse.sessionKey;
                        var pointKey = await body_parse.pointKey;
                        var data = await body_parse.data;
                        var type = await body_parse.type;
                        var subtype = await body_parse.subtype;
                        var clientTokenReq = await body_parse.client;
                        
                        
                        var clientTokenMaker = await makeClientToken(ip,origin,pointKey,sessionKey,org_key);
                        console.log('2+++++' + clientTokenMaker + "-------------------------------------------" + clientTokenReq + "-" + ip + "-" + origin + "-" + pointKey + "|" + sessionKey + "|" +org_key);
                        if(clientTokenMaker == clientTokenReq){
                            
                            const eventTP_FR = await eventTP(client,ip,sessionKey,pointKey,type,subtype,data,ch_platform,UserAgent,org_key);
                            
                            var body_res = await eventTP_FR;
                           const response = await {
                                  statusCode: 200,
                                  headers: headersRes,
                                  body:JSON.stringify(body_res)
                              };
                              return await response;
                        }else{
                             const response = await {
                                  statusCode: 423,
                                  headers: headersRes,
                                  body:JSON.stringify({"status":false,"msg": "sorry but your client token not validate"})
                              };
                              return await response;
                        }
                      
                    }
    
                                
                  
                    
            } catch (e) {
                console.error(e);
            } finally {
                // await client.close();
            }

    // var body_res_a = await JSON.stringify(body_res);
    // const response = await {
    //       statusCode: 200,
    //       body:body_res_a
    //   };
    //   return await response;
}
